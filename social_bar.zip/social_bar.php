<?php
// Plugin developed and coded by Jake, https://jakee.pw/
// Tested with wonderCMS 2.4.0
if(defined('VERSION'))
	define('version', VERSION);
	defined('version') OR die('Direct access is not allowed.');
	 wCMS::addListener('css', 'LoadSocialBarCSS');
	 wCMS::addListener('css', 'LoadSocialBarHTML');
	 
function LoadSocialBarCSS($args) {
	$script = <<<'EOT'
	
	<link rel="stylesheet" href="plugins/social_bar/css/bar.css" type="text/css" media="screen" charset="utf-8">
EOT;
	if(version<'2.0.0')
		array_push($args[0], $script);
	else
		$args[0].=$script;
	return $args;
}
function LoadSocialBarHTML($args) {
	$script = <<<'EOT'
	
	<div class="row social-bar">
        <ul class="social-icons">
		<li><a href="https://yourfacebookhere"><i class="fa fa-facebook"></i></a></li>
		<li><a href="https://yourtwitter"><i class="fa fa-twitter"></i></a></li>
		<li><a href="https://yourinstagramhere"><i class="fa fa-instagram"></i></a></li>
        </ul>
    </div>
	<div class="spacer-custom"></div>
EOT;
	if(version<'2.0.0')
		array_push($args[0], $script);
	else
		$args[0].=$script;
	return $args;
}
?>